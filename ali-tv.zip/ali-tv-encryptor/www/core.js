// نفس صيغة tools/ali_tool.py تماماً: base64url( iv(12) || ciphertext || tag ) ، AAD = اسم القناة
const b64u = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const ub64u = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), c => c.charCodeAt(0));
const genKey = () => b64u(crypto.getRandomValues(new Uint8Array(32)));
async function importKey(k) {
  const raw = ub64u(k.trim());
  if (raw.length !== 32) throw new Error('المفتاح يجب أن يكون 32 بايت (AES-256)');
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
async function encUrl(key, url, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aad) }, key, new TextEncoder().encode(url)));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return b64u(out);
}
async function buildConnect(keyStr, categories, channels, matches) {
  const key = await importKey(keyStr);
  const outCh = [];
  for (let i = 0; i < channels.length; i++) {
    const c = channels[i];
    outCh.push({ id: c.id || 'c' + i, name: c.name, logo: c.logo || '', category: c.category || '', quality: c.quality || 'HD', type: c.type || 'live', u: await encUrl(key, c.url, c.name) });
  }
  const outM = [];
  for (const m of matches) {
    const name = `${m.team1 || ''} vs ${m.team2 || ''}`;
    outM.push({ tournament: m.tournament || '', team1: m.team1 || '', team2: m.team2 || '', name, u: await encUrl(key, m.streamUrl, name) });
  }
  return { v: 1, updated: new Date().toISOString().slice(0, 19) + '+00:00', categories, matchSlides: outM, channels: outCh };
}
function parseM3U(text) {
  const chans = [], cats = {}; let cur = null;
  for (let line of text.split(/\r?\n/)) {
    line = line.trim();
    if (line.startsWith('#EXTINF')) {
      const g = line.match(/group-title="([^"]*)"/), l = line.match(/tvg-logo="([^"]*)"/);
      cur = { name: (line.split(',').slice(1).join(',').trim()) || 'قناة', logo: l ? l[1] : '', group: g ? g[1] : 'عام' };
    } else if (line && !line.startsWith('#') && cur) {
      cur.url = line;
      if (!(cur.group in cats)) cats[cur.group] = 'g' + Object.keys(cats).length;
      cur.category = cats[cur.group]; chans.push(cur); cur = null;
    }
  }
  return { categories: Object.entries(cats).map(([name, id]) => ({ id, name, icon: 'fa-tv' })), channels: chans };
}
async function xtApi(server, user, pass, action) {
  const q = new URLSearchParams({ username: user, password: pass, action });
  const r = await fetch(`${server}/player_api.php?${q}`, { headers: { 'User-Agent': 'okhttp/4.9' } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
const XT = { live: ['get_live_categories', 'get_live_streams', 'fa-tv'], movie: ['get_vod_categories', 'get_vod_streams', 'fa-film'] };
if (typeof module !== 'undefined') module.exports = { genKey, buildConnect, parseM3U, encUrl, importKey, b64u, ub64u };
